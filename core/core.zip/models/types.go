package models

import "time"

type User struct {
	ID                int       `json:"id"`
	Username          string    `json:"username"`
	Password          string    `json:"password,omitempty"` // Omitted in JSON output usually
	Email             string    `json:"email"`
	MinecraftUsername string    `json:"minecraftUsername"`
	IsAdmin           bool      `json:"isAdmin"`
	Is2FAEnabled      bool      `json:"is2FAEnabled"`
	Permissions       string    `json:"permissions"`
	PublicID          string    `json:"publicId"`
	CreatedAt         time.Time `json:"createdAt"`
}

type Node struct {
	ID      int    `json:"id"`
	Name    string `json:"name"`
	Address string `json:"ip"`
	Token   string `json:"apiKey,omitempty"`
	Status  string `json:"status"`
	IsLocal bool   `json:"isLocal"`
	Tags    string `json:"tags"`

	// NEU: Link / Tunnel Configuration
	LinkEnabled   bool   `json:"linkEnabled"`   // Soll der Node Links nutzen?
	LinkInstances int    `json:"linkInstances"` // Anzahl der Links (Standard 1 für Sidecar Logic)
	LinkSecret    string `json:"linkSecret"`    // Das Secret, das die Links nutzen sollen

	CreatedAt time.Time `json:"createdAt"`
}

type Server struct {
	ID           int       `json:"id"`
	UUID         string    `json:"uuid"`
	Name         string    `json:"name"`
	NodeID       int       `json:"nodeId"`
	NodeName     string    `json:"node"` // Joined Field
	OwnerID      int       `json:"ownerId"`
	OwnerName    string    `json:"owner"` // Joined Field
	GameImage    string    `json:"image"`
	Port         int       `json:"port"`
	Memory       int       `json:"memory"`
	StartCommand string    `json:"startCommand"`
	Status       string    `json:"status"`
	CreatedAt    time.Time `json:"createdAt"`
}

type Module struct {
	ID        int    `json:"id"`
	Name      string `json:"name"`
	Type      string `json:"type"`
	Icon      string `json:"icon"`
	URL       string `json:"url,omitempty"`
	IsEnabled bool   `json:"isEnabled"`
	IsSystem  bool   `json:"isSystem"`
	Position  int    `json:"position"`
}
