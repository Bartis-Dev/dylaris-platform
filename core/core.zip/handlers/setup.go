package handlers

import (
	"database/sql"
	"dylaris-core/config"
	"dylaris-core/database"
	"dylaris-core/models"
	"dylaris-core/store" // NEU
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"
	"golang.org/x/crypto/bcrypt"
)

type AppState struct {
	// DB *sql.DB // ALTE WAY: Entfernt
	Store store.Store // NEU: Interface
	Redis *redis.Client
}

type SetupHandler struct {
	State *AppState
}

func NewSetupHandler(state *AppState) *SetupHandler {
	return &SetupHandler{State: state}
}

type FinishSetupRequest struct {
	License  string `json:"license"`
	Database struct {
		Host     string `json:"host"`
		Port     string `json:"port"`
		User     string `json:"user"`
		Password string `json:"password"`
		Name     string `json:"name"`
	} `json:"database"`
	Admin struct {
		Username string `json:"username"`
		Password string `json:"password"`
	} `json:"admin"`
}

func (h *SetupHandler) TestConnectionHandler(w http.ResponseWriter, r *http.Request) {
	// ... (Code wie zuvor, nutzt temporäre database.InitDB, das ist okay für Tests) ...
	// Für den Test bauen wir kurz eine direkte Verbindung auf, ohne den Store zu nutzen.
	var req FinishSetupRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		sendJSONError(w, "Invalid JSON", http.StatusBadRequest)
		return
	}
	tempCfg := config.Config{
		DBHost: req.Database.Host, DBPort: req.Database.Port,
		DBUser: req.Database.User, DBPassword: req.Database.Password, DBName: req.Database.Name,
	}
	tempDB, err := database.InitDB(tempCfg)
	if err != nil {
		sendJSONError(w, fmt.Sprintf("Connection Failed: %v", err), http.StatusServiceUnavailable)
		return
	}
	defer tempDB.Close()
	json.NewEncoder(w).Encode(map[string]interface{}{"success": true, "message": "Connection Successful!"})
}

func (h *SetupHandler) FinishSetupHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		sendJSONError(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req FinishSetupRequest
	json.NewDecoder(r.Body).Decode(&req)

	config.WriteDBConfig(req.Database.Host, req.Database.Port, req.Database.User, req.Database.Password, req.Database.Name)

	// DB Init
	tempCfg := config.Config{
		DBHost: req.Database.Host, DBPort: req.Database.Port,
		DBUser: req.Database.User, DBPassword: req.Database.Password, DBName: req.Database.Name,
	}
	newDB, err := database.InitDB(tempCfg)
	if err != nil {
		sendJSONError(w, "DB Init failed", http.StatusInternalServerError)
		return
	}
	defer newDB.Close()

	// Initialen Store erstellen für Admin-Creation
	tempStore := store.NewPostgresStore(newDB)

	hashedPassword, _ := bcrypt.GenerateFromPassword([]byte(req.Admin.Password), bcrypt.DefaultCost)

	// Prüfen ob User existiert via Store
	existingUser, err := tempStore.GetUserByUsername(req.Admin.Username)

	if err == sql.ErrNoRows {
		// Create
		admin := &models.User{ // Nutze jetzt core/models
			Username: req.Admin.Username,
			Password: string(hashedPassword),
			IsAdmin:  true,
			PublicID: uuid.New().String(),
		}
		if err := tempStore.CreateUser(admin); err != nil {
			sendJSONError(w, fmt.Sprintf("Create Admin failed: %v", err), 500)
			return
		}
	} else if err == nil {
		// Update (Wir nutzen hier direkt SQL weil UpdateUser im Interface noch zu generisch ist,
		// oder wir erweitern UpdateUser. Für Setup lassen wir es simple via Interface UpdateUser Logic)
		existingUser.Password = string(hashedPassword)
		existingUser.IsAdmin = true
		if existingUser.PublicID == "" {
			existingUser.PublicID = uuid.New().String()
		}

		tempStore.UpdateUser(existingUser)
	}

	json.NewEncoder(w).Encode(map[string]interface{}{"success": true, "message": "Setup complete! Restart backend."})
}
