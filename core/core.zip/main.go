package main

import (
	"log"
	"net/http"

	"dylaris-core/config"
	"dylaris-core/database"
	"dylaris-core/handlers"
	"dylaris-core/services" // NEU
	"dylaris-core/store"

	"github.com/gorilla/mux"
	"github.com/rs/cors"
)

func main() {
	cfg, err := config.LoadConfig()
	if err != nil {
		log.Println("Config Info:", err)
	}

	appState := &handlers.AppState{}

	// DB Init
	if cfg.DBHost != "" {
		db, err := database.InitDB(cfg)
		if err != nil {
			log.Println("⚠️  DB Error (Setup erforderlich):", err)
		} else {
			appState.Store = store.NewPostgresStore(db)
			log.Println("✅ DB & Store verbunden.")

			if cfg.MySQLMigrationDSN != "" {
				database.MigrateFromMySQL(db, cfg.MySQLMigrationDSN)
			}
		}
	} else {
		log.Println("ℹ️  Keine DB-Config. Setup-Modus aktiv.")
	}

	// Redis Init
	redisClient, err := database.InitRedis(cfg)
	if err != nil {
		log.Println("⚠️  Redis Error:", err)
	} else {
		appState.Redis = redisClient
		log.Println("✅ Redis verbunden.")

		// NEU: Discovery Service starten (wenn DB da ist)
		if appState.Store != nil {
			discovery := services.NewDiscoveryService(appState.Store, redisClient, cfg.ClusterSecret)
			discovery.Start()
		}
	}

	// Handlers
	authHandler := handlers.NewAuthHandler(appState, cfg.JWTSecret)
	fileHandler := handlers.NewFileHandler()
	moduleHandler := handlers.NewModuleHandler(appState)
	userHandler := handlers.NewUserHandler(appState)
	setupHandler := handlers.NewSetupHandler(appState)
	nodeHandler := handlers.NewNodeHandler(appState)
	serverHandler := handlers.NewServerHandler(appState)
	// DaemonConnectHandler ist jetzt obsolet, lassen wir aber drin
	daemonHandler := handlers.NewDaemonHandler(appState)

	router := mux.NewRouter()
	api := router.PathPrefix("/api").Subrouter()

	// ... (Restliche Routen bleiben exakt gleich wie vorher) ...
	// Ich kürze hier ab, da sich an den Routen nichts ändert.
	// Bitte kopiere die Routen aus deiner existierenden main.go oder dem vorherigen Block.

	api.HandleFunc("/status", authHandler.StatusHandler).Methods("GET", "OPTIONS")
	api.HandleFunc("/setup/test", setupHandler.TestConnectionHandler).Methods("POST", "OPTIONS")
	api.HandleFunc("/setup/finish", setupHandler.FinishSetupHandler).Methods("POST", "OPTIONS")
	api.HandleFunc("/login", authHandler.LoginHandler).Methods("POST", "OPTIONS")
	api.HandleFunc("/daemon/connect", daemonHandler.DaemonConnectHandler)

	api.HandleFunc("/profile", authHandler.AuthMiddleware(authHandler.GetProfileHandler)).Methods("GET", "OPTIONS")
	api.HandleFunc("/profile/update", authHandler.AuthMiddleware(authHandler.UpdateProfileHandler)).Methods("POST", "OPTIONS")

	api.HandleFunc("/nodes", authHandler.AuthMiddleware(nodeHandler.GetNodes)).Methods("GET", "OPTIONS")
	api.HandleFunc("/nodes", authHandler.AuthMiddleware(nodeHandler.CreateNode)).Methods("POST", "OPTIONS")
	api.HandleFunc("/nodes/{id}", authHandler.AuthMiddleware(nodeHandler.DeleteNode)).Methods("DELETE", "OPTIONS")

	api.HandleFunc("/servers", authHandler.AuthMiddleware(serverHandler.GetServers)).Methods("GET", "OPTIONS")
	api.HandleFunc("/servers", authHandler.AuthMiddleware(serverHandler.CreateServer)).Methods("POST", "OPTIONS")

	api.HandleFunc("/files", authHandler.AuthMiddleware(fileHandler.GetFilesHandler)).Methods("GET", "OPTIONS")
	api.HandleFunc("/files/content", authHandler.AuthMiddleware(fileHandler.GetFileContentHandler)).Methods("GET", "OPTIONS")
	api.HandleFunc("/files/save", authHandler.AuthMiddleware(fileHandler.SaveFileHandler)).Methods("POST", "OPTIONS")
	api.HandleFunc("/files/create", authHandler.AuthMiddleware(fileHandler.CreateFileHandler)).Methods("POST", "OPTIONS")
	api.HandleFunc("/files/rename", authHandler.AuthMiddleware(fileHandler.RenameFileHandler)).Methods("POST", "OPTIONS")
	api.HandleFunc("/files/copy", authHandler.AuthMiddleware(fileHandler.CopyFileHandler)).Methods("POST", "OPTIONS")
	api.HandleFunc("/files/upload", authHandler.AuthMiddleware(fileHandler.UploadFileHandler)).Methods("POST", "OPTIONS")
	api.HandleFunc("/files/delete", authHandler.AuthMiddleware(fileHandler.DeleteFileHandler)).Methods("POST", "OPTIONS")
	api.HandleFunc("/files/download", fileHandler.DownloadFileHandler).Methods("GET", "OPTIONS")

	api.HandleFunc("/modules", authHandler.AuthMiddleware(moduleHandler.GetModulesHandler)).Methods("GET", "OPTIONS")
	api.HandleFunc("/modules", authHandler.AuthMiddleware(moduleHandler.CreateModuleHandler)).Methods("POST", "OPTIONS")
	api.HandleFunc("/modules/{id}", authHandler.AuthMiddleware(moduleHandler.DeleteModuleHandler)).Methods("DELETE", "OPTIONS")

	api.HandleFunc("/users", authHandler.AuthMiddleware(userHandler.GetAllUsers)).Methods("GET", "OPTIONS")
	api.HandleFunc("/users", authHandler.AuthMiddleware(userHandler.CreateUser)).Methods("POST", "OPTIONS")
	api.HandleFunc("/users/{id}", authHandler.AuthMiddleware(userHandler.DeleteUser)).Methods("DELETE", "OPTIONS")

	c := cors.New(cors.Options{
		AllowedOrigins:   []string{cfg.FrontendURL},
		AllowedMethods:   []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowedHeaders:   []string{"Authorization", "Content-Type", "X-Dylaris-Token"},
		AllowCredentials: true,
	})
	handler := c.Handler(router)

	log.Printf("🚀 Dylaris Backend running on port %s", cfg.APIPort)
	log.Fatal(http.ListenAndServe(":"+cfg.APIPort, handler))
}
